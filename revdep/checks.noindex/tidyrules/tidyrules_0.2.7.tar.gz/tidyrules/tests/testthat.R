library(testthat)
library(tidyrules)

test_check("tidyrules")
