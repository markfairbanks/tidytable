library(testthat)
library(bbknnR)

test_check("bbknnR")
