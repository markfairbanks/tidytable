library(testthat)
library(ffsimulator)
library(checkmate)

test_check("ffsimulator")
