#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom rlang .data
#' @importFrom rlang :=
#' @importFrom rlang as_label
#' @importFrom rlang as_name
#' @importFrom rlang enquo
#' @importFrom rlang enquos
#' @importFrom rlang eval_tidy
#' @importFrom rlang expr
#' @importFrom rlang sym
#' @importFrom rlang syms
## usethis namespace: end
NULL
