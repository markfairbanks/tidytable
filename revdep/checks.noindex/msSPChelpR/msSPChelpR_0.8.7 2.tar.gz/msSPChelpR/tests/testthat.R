library(testthat)
library(msSPChelpR)

test_check("msSPChelpR")
