#' Data.table helpers
#'
#' See data.table package for details.
#'
#' @name data.table
#' @keywords internal
#' @export .N .SD
#' @importFrom data.table .N .SD

NULL